package com.fit2081.eventmanagementapplication;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "categories")
public class Category {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "cat_pid")
    private int catPid;
    @ColumnInfo(name = "cat_id")
    private String catId;
    @ColumnInfo(name = "cat_name")
    private String catName;
    @ColumnInfo(name = "event_count")
    private int eventCount;
    @ColumnInfo(name = "is_active")
    private boolean isActive;
    @ColumnInfo(name = "category_location")
    private String categoryLocation;

    public Category(String catId, String catName, int eventCount, boolean isActive, String categoryLocation) {
        this.catId = catId;
        this.catName = catName;
        this.eventCount = eventCount;
        this.isActive = isActive;
        this.categoryLocation = categoryLocation;
    }

    public int getCatPid() {
        return catPid;
    }

    public void setCatPid(int catPid) {
        this.catPid = catPid;
    }
    public String getCatId() {
        return catId;
    }

    public void setCatId(String catId) {
        this.catId = catId;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    public int getEventCount() {
        return eventCount;
    }

    public void setEventCount(int eventCount) {
        this.eventCount = eventCount;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }
    public String getCategoryLocation() {
        return categoryLocation;
    }

    public void setCategoryLocation(String categoryLocation) {
        this.categoryLocation = categoryLocation;
    }

}
