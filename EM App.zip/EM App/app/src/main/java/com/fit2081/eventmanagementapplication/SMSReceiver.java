package com.fit2081.eventmanagementapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

public class SMSReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        SmsMessage[] messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        for (int i = 0; i < messages.length; i++) {
            SmsMessage currentMessage = messages[i];
            String message = currentMessage.getDisplayMessageBody();

            Intent msgIntentCategory = new Intent();
            msgIntentCategory.setAction(Keys.SMS_FILTER_CATEGORY);
            msgIntentCategory.putExtra(Keys.SMS_MSG_KEY_CATEGORY, message);
            context.sendBroadcast(msgIntentCategory);

            Intent msgIntentEvent = new Intent();
            msgIntentEvent.setAction(Keys.SMS_FILTER_EVENT);
            msgIntentEvent.putExtra(Keys.SMS_MSG_KEY_EVENT, message);
            context.sendBroadcast(msgIntentEvent);
        }
    }
}