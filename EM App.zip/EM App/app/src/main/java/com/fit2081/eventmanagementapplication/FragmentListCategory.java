package com.fit2081.eventmanagementapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.fit2081.eventmanagementapplication.provider.EventManagementViewModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;

public class FragmentListCategory extends Fragment {
    ArrayList<Category> categoryData;
    MyCategoryAdapter categoryAdapter;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    private EventManagementViewModel categoryViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View fragmentView = inflater.inflate(R.layout.fragment_list_category, container, false);
        categoryData = new ArrayList<>();
        recyclerView = fragmentView.findViewById(R.id.category_recycler_view);

        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);

        categoryAdapter = new MyCategoryAdapter();
        recyclerView.setAdapter(categoryAdapter);

        categoryViewModel = new ViewModelProvider(this).get(EventManagementViewModel.class);
        categoryViewModel.getAllCategories().observe(getViewLifecycleOwner(), newData -> {
            categoryAdapter.setCategoryData((ArrayList<Category>) newData);
            categoryAdapter.notifyDataSetChanged();
        });

        return fragmentView;
    }
}