package com.fit2081.eventmanagementapplication.provider;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.fit2081.eventmanagementapplication.Category;
import com.fit2081.eventmanagementapplication.Event;

import java.util.List;

@Dao
public interface EventManagementDAO {
    @Query("SELECT * FROM categories")
    LiveData<List<Category>> getAllCategories();

    @Insert
    void addCategory(Category category);

    @Query("DELETE FROM categories")
    void deleteAllCategories();

    @Query("SELECT cat_id FROM categories")
    LiveData<List<String>> getAllCategoryIds();

    @Query("UPDATE categories SET event_count = event_count + 1 WHERE cat_id = :catID")
    void updateCategory(String catID);

    @Query("SELECT * FROM events")
    LiveData<List<Event>> getAllEvents();

    @Insert
    void addEvent(Event event);

    @Query("DELETE FROM events")
    void deleteAllEvents();

    @Query("DELETE FROM events WHERE event_id = :eventID")
    void deleteEvent(String eventID);
}
