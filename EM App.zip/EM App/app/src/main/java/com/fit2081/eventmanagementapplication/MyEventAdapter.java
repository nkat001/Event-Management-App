package com.fit2081.eventmanagementapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyEventAdapter extends RecyclerView.Adapter<MyEventAdapter.EventCustomViewHolder> {
    ArrayList<Event> eventData = new ArrayList<>();

    public void setEventData(ArrayList<Event> eventData) {
        this.eventData = eventData;
    }

    @NonNull
    @Override
    public EventCustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_card_layout, parent, false);
        MyEventAdapter.EventCustomViewHolder viewHolder = new MyEventAdapter.EventCustomViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull EventCustomViewHolder holder, int position) {
        holder.tvEventId.setText(eventData.get(position).getEventId());
        holder.tvEventName.setText(eventData.get(position).getEventName());
        holder.tvEventCatId.setText(eventData.get(position).getEventCatId());
        holder.tvEventTicketsAvailable.setText(String.valueOf(eventData.get(position).getEventTicketsAvailable()));
        if (eventData.get(position).isEventIsActive()) {
            holder.tvEventIsActive.setText("Active");
        } else {
            holder.tvEventIsActive.setText("Inactive");
        }

        holder.cardView.setOnClickListener(v -> {
            String eventName = eventData.get(position).getEventName();

            Context context = holder.cardView.getContext();
            Intent intent = new Intent(context, EventGoogleResult.class);
            intent.putExtra(Keys.EVENT_FORM_EVENT_NAME, eventName);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        if (this.eventData != null) {
            return this.eventData.size();
        } else {
            return 0;
        }
    }

    public class EventCustomViewHolder extends RecyclerView.ViewHolder {
        public TextView tvEventId;
        public TextView tvEventName;
        public TextView tvEventCatId;
        public TextView tvEventTicketsAvailable;
        public TextView tvEventIsActive;
        public View cardView;

        public EventCustomViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView;
            tvEventId = itemView.findViewById(R.id.tv_event_card_event_id);
            tvEventName = itemView.findViewById(R.id.tv_event_card_event_name);
            tvEventCatId = itemView.findViewById(R.id.tv_event_card_category_id);
            tvEventTicketsAvailable = itemView.findViewById(R.id.tv_event_card_tickets_available);
            tvEventIsActive = itemView.findViewById(R.id.tv_event_card_event_status);
        }
    }
}
