package com.fit2081.eventmanagementapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MyCategoryAdapter extends RecyclerView.Adapter<MyCategoryAdapter.CategoryCustomViewHolder> {
    ArrayList<Category> categoryData;

    public void setCategoryData(ArrayList<Category> categoryData) {
        this.categoryData = categoryData;
    }

    @NonNull
    @Override
    public CategoryCustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.category_card_layout, parent, false);
        MyCategoryAdapter.CategoryCustomViewHolder viewHolder = new CategoryCustomViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryCustomViewHolder holder, int position) {
        holder.tvCatId.setText(categoryData.get(position).getCatId());
        holder.tvCatName.setText(categoryData.get(position).getCatName());
        holder.tvEventCount.setText(String.valueOf(categoryData.get(position).getEventCount()));
        if (categoryData.get(position).isActive()) {
            holder.tvIsActive.setText("Yes");
        } else {
            holder.tvIsActive.setText("No");
        }

        holder.cardView.setOnClickListener(v -> {
            String categoryLocation = categoryData.get(position).getCategoryLocation();
            String categoryName = categoryData.get(position).getCatName();

            Context context = holder.cardView.getContext();
            Intent intent = new Intent(context, GoogleMapsActivity.class);
            intent.putExtra(Keys.CATEGORY_LOCATION, categoryLocation);
            intent.putExtra(Keys.CATEGORY_NAME, categoryName);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        if (this.categoryData != null) {
            return this.categoryData.size();
        } else {
            return 0;
        }
    }

    public class CategoryCustomViewHolder extends RecyclerView.ViewHolder {
        public TextView tvCatId;
        public TextView tvCatName;
        public TextView tvEventCount;
        public TextView tvIsActive;
        public View cardView;

        public CategoryCustomViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView;
            tvCatId = itemView.findViewById(R.id.tv_catId);
            tvCatName = itemView.findViewById(R.id.tv_catName);
            tvEventCount = itemView.findViewById(R.id.tv_eventCount);
            tvIsActive = itemView.findViewById(R.id.tv_catIsActive);
        }
    }
}
