package com.fit2081.eventmanagementapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GestureDetectorCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.fit2081.eventmanagementapplication.provider.EventManagementViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Dashboard extends AppCompatActivity {
    NavigationView navigationView;
    EditText etEventId;
    EditText etEventName;
    EditText etCategoryId;
    EditText etTicketsAvailable;
    Switch isActiveEvent;
    FloatingActionButton fab;
    Toolbar dashboardToolbar;
    ActionBarDrawerToggle toggle;
    DrawerLayout drawerLayout;
    Event newEvent;
    View touchpad;
    TextView gesture;
    private GestureDetectorCompat gestureDetector;
    private EventManagementViewModel eventManagementViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.navigation_drawer);
        navigationView = findViewById(R.id.navigationView);

        MyNavigationViewListener myNavigationViewListener = new MyNavigationViewListener();
        navigationView.setNavigationItemSelectedListener(myNavigationViewListener);

        etEventId = findViewById(R.id.editTextEventIdEventForm);
        etEventName = findViewById(R.id.editTextEventNameEventForm);
        etCategoryId = findViewById(R.id.editTextCategoryIdEventForm);
        etTicketsAvailable = findViewById(R.id.editTextNumberTicketsAvailableEventForm);
        isActiveEvent = findViewById(R.id.switchIsActiveEventForm);
        dashboardToolbar = findViewById(R.id.dashboard_toolbar);
        drawerLayout = findViewById(R.id.drawer_layout);
        fab = findViewById(R.id.fab_save_event);
        touchpad = findViewById(R.id.touchpad);
        gesture = findViewById(R.id.tv_gesture);

        ActivityCompat.requestPermissions(this, new String[]{
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_SMS
        }, 0);

        MyBroadCastReceiverEventClass myBroadCastReceiverEventClass = new MyBroadCastReceiverEventClass();
        registerReceiver(myBroadCastReceiverEventClass, new IntentFilter(Keys.SMS_FILTER_EVENT), RECEIVER_EXPORTED);

        dashboardToolbar.setTitle("EM App");
        setSupportActionBar(dashboardToolbar);

        toggle = new ActionBarDrawerToggle(
                this, drawerLayout, dashboardToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        eventManagementViewModel = new ViewModelProvider(this).get(EventManagementViewModel.class);

        FragmentListCategory fragmentListCategory = new FragmentListCategory();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.dashboard_host_container, fragmentListCategory);
        transaction.commit();

        CustomGestureDetector customGestureDetector = new CustomGestureDetector();
        gestureDetector = new GestureDetectorCompat(this, customGestureDetector);
        gestureDetector.setOnDoubleTapListener(customGestureDetector);

        touchpad.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                gestureDetector.onTouchEvent(event);
                return true;
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard_toolbar_options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.option_clear_event_form) {
            clearEventForm();
        } else if (item.getItemId() == R.id.option_delete_all_categories) {
            deleteAllCategories();
        } else if (item.getItemId() == R.id.option_delete_all_events) {
            deleteAllEvents();
        } else {
            throw new Error("Invalid Option");
        }
        return true;
    }

    public void deleteAllCategories() {
        eventManagementViewModel.deleteAllCategories();
        Toast.makeText(this, "Categories deleted", Toast.LENGTH_SHORT).show();
    }

    public void deleteAllEvents() {
        eventManagementViewModel.deleteAllEvents();
        Toast.makeText(this, "Events deleted", Toast.LENGTH_SHORT).show();
    }

    public void clearEventForm() {
        etEventId.setText("");
        etEventName.setText("");
        etCategoryId.setText("");
        etTicketsAvailable.setText("");
        isActiveEvent.setChecked(false);
        Toast.makeText(this, "Event form cleared", Toast.LENGTH_SHORT).show();
    }

    public void onSaveEventButtonClick(View view) {
        String stringEventName = etEventName.getText().toString();
        String stringCategoryId = etCategoryId.getText().toString();

        if (stringEventName.isEmpty()) {
            Toast.makeText(this, "Event name cannot be empty", Toast.LENGTH_SHORT).show();
        } else if (stringCategoryId.isEmpty()) {
            Toast.makeText(this, "Category ID cannot be empty", Toast.LENGTH_SHORT).show();
        } else {
            if (isValidEventName(stringEventName)) {
                incCategoryById(stringCategoryId);
                LiveData<List<Category>> categoryLiveData = eventManagementViewModel.getAllCategories();
                categoryLiveData.observe(this, newData -> {
                    boolean isCategoryFound = false;
                    for (Category category : newData) {
                        if (category.getCatId().equals(stringCategoryId)) {
                            isCategoryFound = true;
                            break;
                        }
                    }
                    if (!isCategoryFound) {
                        Toast.makeText(this, "Category does not exist", Toast.LENGTH_SHORT).show();
                    } else {
                        String stringEventTickets = etTicketsAvailable.getText().toString();
                        boolean eventIsActive = isActiveEvent.isChecked();

                        int numberOfTickets = 0;
                        try {
                            numberOfTickets = Integer.parseInt(stringEventTickets);
                        } catch (NumberFormatException e) {
                            Log.e("NumberFormatException", "Failed to parse event count: " + stringEventTickets);
                        }
                        etEventId.setText(String.format("E" + HelperClass.characterGenerator() + HelperClass.characterGenerator() + "-" + HelperClass.fiveDigitGenerator()));
                        String stringEventId = etEventId.getText().toString();
                        if ((!stringEventTickets.isEmpty()) && (Integer.parseInt(stringEventTickets) < 0)) {
                            newEvent = new Event(stringEventId, stringEventName, stringCategoryId, numberOfTickets, eventIsActive);
                        } else {
                            newEvent = new Event(stringEventId, stringEventName, stringCategoryId, numberOfTickets, eventIsActive);
                        }

                        eventManagementViewModel.insertEvent(newEvent);

                        Snackbar mySnackbar = Snackbar.make(view, "Event saved", Snackbar.LENGTH_LONG);
                        mySnackbar.setAction("Undo", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                eventManagementViewModel.deleteEvent(stringEventId);
                                Toast.makeText(Dashboard.this, "Event save undone", Toast.LENGTH_SHORT).show();
                            }
                        });
                        mySnackbar.show();
                    }
                    categoryLiveData.removeObservers(this);
                });
            }
        }
    }
    private  void incCategoryById(String id){
        eventManagementViewModel.updateCategory(id);
    }

    class MyNavigationViewListener implements NavigationView.OnNavigationItemSelectedListener {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            int itemId = menuItem.getItemId();

            if (itemId == R.id.viewCategories) {
                goToCategoryList();
                Toast.makeText(Dashboard.this, "Viewing all categories", Toast.LENGTH_SHORT).show();
            } else if (itemId == R.id.addCategory) {
                goToAddCategory();
            } else if (itemId == R.id.viewEvents) {
                goToEventList();
                Toast.makeText(Dashboard.this, "Viewing all events", Toast.LENGTH_SHORT).show();
            } else if (itemId == R.id.logout) {
                goToLoginPage();
            } else {
                Toast.makeText(Dashboard.this, "Invalid Option", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
    }

    public static boolean isValidEventName(String eventName) {
        return eventName.matches(".*[a-zA-Z].*") && eventName.matches("[a-zA-Z0-9\\s]+");
    }

    public void goToEventList() {
        Intent intent = new Intent(this, EventList.class);
        startActivity(intent);
    }

    public void goToCategoryList() {
        Intent intent = new Intent(this, CategoryList.class);
        startActivity(intent);
    }

    public void goToAddCategory() {
        Intent intent = new Intent(this, NewCategoryForm.class);
        startActivity(intent);
    }

    public void goToLoginPage() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    class MyBroadCastReceiverEventClass extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String message = intent.getStringExtra(Keys.SMS_MSG_KEY_EVENT);
            categoryStringTokenizer(message);
        }

        public void categoryStringTokenizer(String message) {
            try {
                StringTokenizer st1 = new StringTokenizer(message, ";");

                if (st1.countTokens() != 4) {
                    Toast.makeText(Dashboard.this, "Invalid number of parameters", Toast.LENGTH_SHORT).show();
                    return;
                }

                String eventName = st1.nextToken();
                if (!eventName.startsWith("event:") || (message.endsWith(";"))) {
                    Toast.makeText(Dashboard.this, "Invalid starting format", Toast.LENGTH_SHORT).show();
                    return;
                }

                String[] parts = eventName.split(":");
                if (parts.length != 2) {
                    Toast.makeText(Dashboard.this, "Invalid format of category name", Toast.LENGTH_SHORT).show();
                    return;
                }

                String stringEventName = parts[1].trim();
                String catId = st1.nextToken();
                int ticketsAvailable = Integer.parseInt(st1.nextToken());

                String isEventActive = st1.nextToken().trim();
                if (!isEventActive.equalsIgnoreCase("TRUE") && !isEventActive.equalsIgnoreCase("FALSE")) {
                    Toast.makeText(Dashboard.this, "Invalid format of category status", Toast.LENGTH_SHORT).show();
                    return;
                }

                etEventName.setText(stringEventName);
                etCategoryId.setText(catId);
                etTicketsAvailable.setText(String.valueOf(ticketsAvailable));
                isActiveEvent.setChecked(isEventActive.equalsIgnoreCase("TRUE"));
            } catch (NumberFormatException e) {
                Toast.makeText(Dashboard.this, "Invalid format", Toast.LENGTH_SHORT).show();
            }
        }
    }

    class CustomGestureDetector extends GestureDetector.SimpleOnGestureListener {
        public boolean onDoubleTap(@NonNull MotionEvent motionEvent) {
            gesture.setText("On Double Tap");
            onSaveEventButtonClick(touchpad);
            return super.onDoubleTap(motionEvent);
        }

        public void onLongPress(@NonNull MotionEvent motionEvent) {
            gesture.setText("On Long Press");
            clearEventForm();
            super.onLongPress(motionEvent);
        }
    }
}