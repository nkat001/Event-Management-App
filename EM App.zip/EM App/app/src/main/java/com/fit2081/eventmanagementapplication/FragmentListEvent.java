package com.fit2081.eventmanagementapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.fit2081.eventmanagementapplication.provider.EventManagementViewModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;

public class FragmentListEvent extends Fragment {
    ArrayList<Event> eventData;
    MyEventAdapter eventAdapter;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    private EventManagementViewModel eventViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View fragmentView = inflater.inflate(R.layout.fragment_list_event, container, false);
        eventData = new ArrayList<>();
        recyclerView = fragmentView.findViewById(R.id.event_recycler_view);

        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);

        eventAdapter = new MyEventAdapter();
        recyclerView.setAdapter(eventAdapter);

        eventViewModel = new ViewModelProvider(this).get(EventManagementViewModel.class);
        eventViewModel.getAllEvents().observe(getViewLifecycleOwner(), newData -> {
            eventAdapter.setEventData((ArrayList<Event>) newData);
            eventAdapter.notifyDataSetChanged();
        });

        return fragmentView;
    }
}