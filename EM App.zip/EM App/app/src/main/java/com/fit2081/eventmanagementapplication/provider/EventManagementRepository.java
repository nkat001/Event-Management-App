package com.fit2081.eventmanagementapplication.provider;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.fit2081.eventmanagementapplication.Category;
import com.fit2081.eventmanagementapplication.Event;

import java.util.List;

public class EventManagementRepository {
    private EventManagementDAO eventManagementDAO;
    private LiveData<List<Category>> getAllCategories;
    private LiveData<List<Event>> getAllEvents;
    private LiveData<List<String>> getAllCategoryIds;
    EventManagementRepository(Application application) {
        EventManagementDatabase database = EventManagementDatabase.getDatabase(application);
        eventManagementDAO = database.eventManagementDAO();
        getAllCategories = eventManagementDAO.getAllCategories();
        getAllEvents = eventManagementDAO.getAllEvents();
        getAllCategoryIds = eventManagementDAO.getAllCategoryIds();
    }

    LiveData<List<Category>> getAllCategories() {
        return getAllCategories;
    }

    LiveData<List<String>> getAllCategoryIds() {
        return getAllCategoryIds;
    }

    void updateCategory(String catId) {
        EventManagementDatabase.databaseWriteExecutor.execute(() -> {
            eventManagementDAO.updateCategory(catId);
        });
    }

    LiveData<List<Event>> getGetAllEvents() {
        return getAllEvents;
    }

    void insertCategory(Category category) {
        EventManagementDatabase.databaseWriteExecutor.execute(() -> {
            eventManagementDAO.addCategory(category);
        });
    }

    void deleteAllCategories() {
        EventManagementDatabase.databaseWriteExecutor.execute(() -> {
            eventManagementDAO.deleteAllCategories();
        });
    }

    void insertEvent(Event event) {
        EventManagementDatabase.databaseWriteExecutor.execute(() -> {
            eventManagementDAO.addEvent(event);
        });
    }

    void deleteEvent(String eventId) {
        EventManagementDatabase.databaseWriteExecutor.execute(() -> {
            eventManagementDAO.deleteEvent(eventId);
        });
    }

    void deleteAllEvents() {
        EventManagementDatabase.databaseWriteExecutor.execute(() -> {
            eventManagementDAO.deleteAllEvents();
        });
    }
}
