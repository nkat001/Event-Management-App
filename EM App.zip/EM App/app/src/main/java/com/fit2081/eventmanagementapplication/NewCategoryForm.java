package com.fit2081.eventmanagementapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.ViewModelProvider;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelUuid;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.fit2081.eventmanagementapplication.provider.EventManagementViewModel;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class NewCategoryForm extends AppCompatActivity {
    EditText etCategoryId;
    EditText etCategoryName;
    EditText etEventCount;
    EditText etEventCatLocation;
    Switch sIsActive;
    Category newCategory;
    private EventManagementViewModel eventManagementViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_category_form);
        etCategoryId = findViewById(R.id.editTextCategoryIdCategoryForm);
        etCategoryName = findViewById(R.id.editTextCategoryNameCategoryForm);
        etEventCount = findViewById(R.id.editTextNumberEventCountCategoryForm);
        etEventCatLocation = findViewById(R.id.edtitTextCategoryLocation);
        sIsActive = findViewById(R.id.switchIsActiveCategoryForm);

        ActivityCompat.requestPermissions(this, new String[]{
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_SMS
        }, 0);

        MyBroadCastReceiverCategoryClass myBroadCastReceiverCategoryClass = new MyBroadCastReceiverCategoryClass();
        registerReceiver(myBroadCastReceiverCategoryClass, new IntentFilter(Keys.SMS_FILTER_CATEGORY), RECEIVER_EXPORTED);

        eventManagementViewModel = new ViewModelProvider(this).get(EventManagementViewModel.class);
    }

    public void onSaveCategoryButtonClick(View view) {
        etCategoryId.setText(String.format("C" + HelperClass.characterGenerator() + HelperClass.characterGenerator() + "-" + HelperClass.fourDigitGenerator()));
        String categoryId = etCategoryId.getText().toString();
        String categoryName = etCategoryName.getText().toString();
        String eventCount = etEventCount.getText().toString();
        String eventCatLocation = etEventCatLocation.getText().toString();
        boolean isActive = sIsActive.isChecked();

        if (categoryName.isEmpty()) {
            Toast.makeText(this, "Category name cannot be empty", Toast.LENGTH_SHORT).show();
        } else if (eventCatLocation.isEmpty()) {
            Toast.makeText(this, "Category location cannot be empty", Toast.LENGTH_SHORT).show();
        } else {
            if (isValidCategoryName(categoryName)) {
                int defaultEventCount = 0;
                try {
                    defaultEventCount = Integer.parseInt(eventCount);
                } catch (NumberFormatException e) {
                    Log.e("NumberFormatException", "Failed to parse event count: " + eventCount);
                }
                if ((!eventCount.isEmpty()) && (Integer.parseInt(eventCount) < 0)) {
                    newCategory = new Category(categoryId, categoryName, 0, isActive, eventCatLocation);
                } else {
                    newCategory = new Category(categoryId, categoryName, defaultEventCount, isActive, eventCatLocation);
                }

                eventManagementViewModel.insertCategory(newCategory);
                Snackbar.make(view, "Category saved", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(NewCategoryForm.this, Dashboard.class);
                        startActivity(intent);
                    }
                }, 1000);

            } else {
                Toast.makeText(this, "Invalid category name", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static boolean isValidCategoryName(String categoryName) {
        return categoryName.matches(".*[a-zA-Z].*") && categoryName.matches("[a-zA-Z0-9\\s]+");
    }

    class MyBroadCastReceiverCategoryClass extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String message = intent.getStringExtra(Keys.SMS_MSG_KEY_CATEGORY);
            categoryStringTokenizer(message);
        }

        public void categoryStringTokenizer(String message) {
            try {
                StringTokenizer st1 = new StringTokenizer(message, ";");

                // see if there are 3 tokens provided
                if (st1.countTokens() != 3) {
                    Toast.makeText(NewCategoryForm.this, "Invalid number of parameters", Toast.LENGTH_SHORT).show();
                    return;
                }

                String eventName = st1.nextToken(); //category:Melbourne
                if (!eventName.startsWith("category:") || (message.endsWith(";"))) {
                    Toast.makeText(NewCategoryForm.this, "Invalid starting format", Toast.LENGTH_SHORT).show();
                    return;
                }

                String[] parts = eventName.split(":");
                if (parts.length != 2) {
                    Toast.makeText(NewCategoryForm.this, "Invalid format of category name", Toast.LENGTH_SHORT).show();
                    return;
                }

                String stringEventName = parts[1].trim();

                int eventCount = Integer.parseInt(st1.nextToken().trim());

                String isEventActive = st1.nextToken().trim();
                if (!isEventActive.equalsIgnoreCase("TRUE") && !isEventActive.equalsIgnoreCase("FALSE")) {
                    Toast.makeText(NewCategoryForm.this, "Invalid format of category status", Toast.LENGTH_SHORT).show();
                    return;
                }

                etCategoryName.setText(stringEventName);
                etEventCount.setText(String.valueOf(eventCount));
                sIsActive.setChecked(isEventActive.equalsIgnoreCase("TRUE"));
            } catch (NumberFormatException e) {
                Toast.makeText(NewCategoryForm.this, "Invalid format of values", Toast.LENGTH_SHORT).show();
            }
        }
    }
}