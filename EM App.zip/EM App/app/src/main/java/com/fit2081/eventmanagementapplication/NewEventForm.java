package com.fit2081.eventmanagementapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import java.util.StringTokenizer;

public class NewEventForm extends AppCompatActivity {
    EditText etEventId;
    EditText etEventName;
    EditText etCategoryId;
    EditText etTicketsAvailable;
    Switch isActiveEvent;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event_form);

        etEventId = findViewById(R.id.editTextEventIdEventForm);
        etEventName = findViewById(R.id.editTextEventNameEventForm);
        etCategoryId = findViewById(R.id.editTextCategoryIdEventForm);
        etTicketsAvailable = findViewById(R.id.editTextNumberTicketsAvailableEventForm);
        isActiveEvent = findViewById(R.id.switchIsActiveEventForm);

        // initialize shared preferences
        sharedPreferences = getSharedPreferences(Keys.EVENT_FILE_NAME, MODE_PRIVATE);

        ActivityCompat.requestPermissions(this, new String[]{
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_SMS
        }, 0);

        MyBroadCastReceiverEventClass myBroadCastReceiverEventClass = new MyBroadCastReceiverEventClass();
        registerReceiver(myBroadCastReceiverEventClass, new IntentFilter(Keys.SMS_FILTER_EVENT), RECEIVER_EXPORTED);
    }

    public void onSaveEventButtonClick(View view) {
        String stringEventName = etEventName.getText().toString();
        String stringCategoryId = etCategoryId.getText().toString();

        if (stringEventName.isEmpty()) {
            Toast.makeText(this, "Event name cannot be empty", Toast.LENGTH_SHORT).show();
        } else if (stringCategoryId.isEmpty()) {
            Toast.makeText(this, "Category ID cannot be empty", Toast.LENGTH_SHORT).show();
        } else {
            etEventId.setText(String.format("E" + HelperClass.characterGenerator() + HelperClass.characterGenerator() + "-" + HelperClass.fiveDigitGenerator()));
            Toast.makeText(this, "Event saved: " + etEventId.getText() + " to " + etCategoryId.getText(), Toast.LENGTH_SHORT).show();
        }
        boolean isActive = isActiveEvent.isChecked();
        saveDataOnSharedPreferences(etEventId.getText().toString(), stringEventName, stringCategoryId, etTicketsAvailable.getText().toString(), isActive);
    }

    private void saveDataOnSharedPreferences(String eventId, String eventName, String catId, String ticketsAvailable, boolean isEventActive) {
        loadDataFromSharedPreferences();
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(Keys.EVENT_FORM_EVENT_ID, eventId);
        editor.putString(Keys.EVENT_FORM_EVENT_NAME, eventName);
        editor.putString(Keys.EVENT_FORM_CATEGORY_ID, catId);

        int numberOfTickets = 0; // Default value if parsing fails
        try {
            numberOfTickets = Integer.parseInt(ticketsAvailable);
        } catch (NumberFormatException e) {
            // Handle NumberFormatException (e.g., log the error)
            Log.e("NumberFormatException", "Failed to parse event count: " + ticketsAvailable);
        }
        editor.putInt(Keys.EVENT_FORM_TICKETS_AVAILABLE, numberOfTickets);
        editor.putBoolean(Keys.EVENT_FORM_IS_ACTIVE, isEventActive);
        editor.apply();

        loadDataFromSharedPreferences();
    }

    private void loadDataFromSharedPreferences() {
        String spEventId = sharedPreferences.getString(Keys.EVENT_FORM_EVENT_ID, "XXX-XXX");
        String spEventName = sharedPreferences.getString(Keys.EVENT_FORM_EVENT_NAME, "Default category name");
        String spCatId = sharedPreferences.getString(Keys.EVENT_FORM_CATEGORY_ID, "XXX-XXX");
        int spTicketsAvailable = sharedPreferences.getInt(Keys.EVENT_FORM_TICKETS_AVAILABLE, 0);
        boolean spIsEventActive = sharedPreferences.getBoolean(Keys.EVENT_FORM_IS_ACTIVE, false);

        etEventId.setText(spEventId);
        etEventName.setText(spEventName);
        etCategoryId.setText(spCatId);
        etTicketsAvailable.setText(String.valueOf(spTicketsAvailable));
        isActiveEvent.setChecked(spIsEventActive);
    }

    class MyBroadCastReceiverEventClass extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String message = intent.getStringExtra(Keys.SMS_MSG_KEY_EVENT);
            categoryStringTokenizer(message);
        }

        public void categoryStringTokenizer(String message) {
            try {
                StringTokenizer st1 = new StringTokenizer(message, ";");

                // see if there are 4 tokens provided
                if (st1.countTokens() != 4) {
                    Toast.makeText(NewEventForm.this, "Invalid number of parameters", Toast.LENGTH_SHORT).show();
                    return;
                }

                String eventName = st1.nextToken(); //event:AFL Grand Finale
                if (!eventName.startsWith("event:") || (message.endsWith(";"))) {
                    Toast.makeText(NewEventForm.this, "Invalid starting format", Toast.LENGTH_SHORT).show();
                    return;
                }

                String[] parts = eventName.split(":");
                if (parts.length != 2) {
                    Toast.makeText(NewEventForm.this, "Invalid format of category name", Toast.LENGTH_SHORT).show();
                    return;
                }

                String stringEventName = parts[1].trim();
                String catId = st1.nextToken();
                int ticketsAvailable = Integer.parseInt(st1.nextToken());

                String isEventActive = st1.nextToken().trim();
                if (!isEventActive.equalsIgnoreCase("TRUE") && !isEventActive.equalsIgnoreCase("FALSE")) {
                    Toast.makeText(NewEventForm.this, "Invalid format of category status", Toast.LENGTH_SHORT).show();
                    return;
                }

                etEventName.setText(stringEventName);
                etCategoryId.setText(catId);
                etTicketsAvailable.setText(String.valueOf(ticketsAvailable));
                isActiveEvent.setChecked(isEventActive.equalsIgnoreCase("TRUE"));
            } catch (NumberFormatException e) {
                Toast.makeText(NewEventForm.this, "Invalid format", Toast.LENGTH_SHORT).show();
            }
        }
    }
}