package com.fit2081.eventmanagementapplication;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "events")
public class Event {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "event_pid")
    private int eventPid;
    @ColumnInfo(name = "event_id")
    private String eventId;
    @ColumnInfo(name = "event_name")
    private String eventName;
    @ColumnInfo(name = "event_cat_id")
    private String eventCatId;
    @ColumnInfo(name = "event_tickets_available")
    private int eventTicketsAvailable;
    @ColumnInfo(name = "event_is_active")
    private boolean eventIsActive;

    public Event(String eventId, String eventName, String eventCatId, int eventTicketsAvailable, boolean eventIsActive) {
        this.eventId = eventId;
        this.eventName = eventName;
        this.eventCatId = eventCatId;
        this.eventTicketsAvailable = eventTicketsAvailable;
        this.eventIsActive = eventIsActive;
    }

    public int getEventPid() {
        return eventPid;
    }

    public void setEventPid(int eventPid) {
        this.eventPid = eventPid;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventCatId() {
        return eventCatId;
    }

    public void setEventCatId(String eventCatId) {
        this.eventCatId = eventCatId;
    }

    public int getEventTicketsAvailable() {
        return eventTicketsAvailable;
    }

    public void setEventTicketsAvailable(int eventTicketsAvailable) {
        this.eventTicketsAvailable = eventTicketsAvailable;
    }

    public boolean isEventIsActive() {
        return eventIsActive;
    }

    public void setEventIsActive(boolean eventIsActive) {
        this.eventIsActive = eventIsActive;
    }
}
