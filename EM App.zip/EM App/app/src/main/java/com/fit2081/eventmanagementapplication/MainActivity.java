package com.fit2081.eventmanagementapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText etUsernameLoginPage;
    EditText etPasswordLoginPage;
    String savedPassword;
    String savedUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etUsernameLoginPage = findViewById(R.id.editTextUsernameLoginPage);
        etPasswordLoginPage = findViewById(R.id.editTextPasswordLoginPage);

        SharedPreferences sharedPreferences = getSharedPreferences(Keys.EM_FILE_NAME, MODE_PRIVATE);
        savedUsername = sharedPreferences.getString(Keys.EM_USERNAME, "");
        savedPassword = sharedPreferences.getString(Keys.EM_PASSWORD, "");
        etUsernameLoginPage.setText(savedUsername);
    }

    public void onRegisterButtonClickInLoginPage(View view) {
        Intent registerIntent = new Intent(this, RegisterPage.class);
        startActivity(registerIntent);
    }

    public void onLoginButtonClickInLoginPage(View view) {
        String stringUsername = etUsernameLoginPage.getText().toString();
        String stringPassword = etPasswordLoginPage.getText().toString();

        if (stringUsername.isEmpty() || stringPassword.isEmpty()) {
            Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
        } else {
            if ((stringPassword.equals(savedPassword)) && (stringUsername.equals(savedUsername))) {
                Intent toDashboardIntent = new Intent(this, Dashboard.class);
                startActivity(toDashboardIntent);
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        }
    }
}