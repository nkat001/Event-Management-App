package com.fit2081.eventmanagementapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterPage extends AppCompatActivity {
    EditText etUsernameRegisterPage;
    EditText etPasswordRegisterPage;
    EditText etPasswordConfirmationRegisterPage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);
        etUsernameRegisterPage = findViewById(R.id.editTextUsernameRegisterPage);
        etPasswordRegisterPage = findViewById(R.id.editTextPasswordRegisterPage);
        etPasswordConfirmationRegisterPage = findViewById(R.id.editTextConfirmPasswordRegisterPage);
    }

    public void onLoginButtonClickInRegisterPage(View view) {
        Intent loginIntent = new Intent(this, MainActivity.class);
        startActivity(loginIntent);
    }

    public void onRegisterButtonClickInRegisterPage(View view) {
        String stringUsername = etUsernameRegisterPage.getText().toString();
        String stringPassword = etPasswordRegisterPage.getText().toString();
        String stringConfirmPassword = etPasswordConfirmationRegisterPage.getText().toString();

        if (stringUsername.isEmpty() || stringPassword.isEmpty() || stringConfirmPassword.isEmpty()) {
            Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!stringPassword.equals(stringConfirmPassword)) {
            Toast.makeText(this, "Passwords should be the same", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Registered Successfully!", Toast.LENGTH_SHORT).show();
            saveDataToSharedPreferences(stringUsername, stringPassword);
            Intent backToLogin = new Intent(this, MainActivity.class);
            startActivity(backToLogin);
        }
    }

    private void saveDataToSharedPreferences(String username, String password) {
        SharedPreferences sharedPreferences = getSharedPreferences(Keys.EM_FILE_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(Keys.EM_USERNAME, username);
        editor.putString(Keys.EM_PASSWORD, password);
        editor.apply();
    }
}