package com.fit2081.eventmanagementapplication;

import java.util.Random;

public class HelperClass {
    public static char characterGenerator() {
        Random random = new Random();
        // generates capital letters from A to Z
        int randomChar = random.nextInt(26) + 65;
        return (char) randomChar;
    }

    public static int fourDigitGenerator() {
        Random random = new Random();
        return random.nextInt(9000) + 1000;
    }

    public static int fiveDigitGenerator() {
        Random random = new Random();
        return random.nextInt(90000) + 10000;
    }
}
