package com.fit2081.eventmanagementapplication.provider;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.fit2081.eventmanagementapplication.Category;
import com.fit2081.eventmanagementapplication.Event;

import java.util.List;

public class EventManagementViewModel extends AndroidViewModel {
    private EventManagementRepository emRepository;
    private LiveData<List<Category>> allCategories;
    private LiveData<List<Event>> allEvents;
    private LiveData<List<String>> getAllCategoryIds;

    public EventManagementViewModel(@NonNull Application application) {
        super(application);
        emRepository = new EventManagementRepository(application);
        allCategories = emRepository.getAllCategories();
        allEvents = emRepository.getGetAllEvents();
        getAllCategoryIds = emRepository.getAllCategoryIds();
    }

    public LiveData<List<Category>> getAllCategories() {
        return allCategories;
    }
    public LiveData<List<Event>>  getAllEvents() {
        return allEvents;
    }
    public LiveData<List<String>> getAllCategoryIds() {
        return getAllCategoryIds;
    }

//    public LiveData<Boolean> isCategoryIdExists(String categoryId) {
//        MutableLiveData<Boolean> isExistsLiveData = new MutableLiveData<>(false);
//        getAllCategoryIds.observeForever(categoryIds -> {
//            isExistsLiveData.setValue(categoryIds.contains(categoryId));
//        });
//        return isExistsLiveData;
//    }

    public void insertCategory(Category category) {
        emRepository.insertCategory(category);
    }

    public void deleteAllCategories() {
        emRepository.deleteAllCategories();
    }

    public void updateCategory(String categoryId) {
        emRepository.updateCategory(categoryId);
    }

    public void insertEvent(Event event) {
        emRepository.insertEvent(event);
    }

    public void deleteEvent(String eventId) {
        emRepository.deleteEvent(eventId);
    }

    public void deleteAllEvents() {
        emRepository.deleteAllEvents();
    }
}
