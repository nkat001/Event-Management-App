package com.fit2081.eventmanagementapplication;

public class Keys {
    public final static String EM_FILE_NAME = "EM Main File";
    public final static String EM_USERNAME = "EM Username";
    public final static String EM_PASSWORD = "EM Password";
    public final static String EVENT_FILE_NAME = "Event File";
    public final static String EVENT_FORM_EVENT_ID = "Event Form Event ID";
    public final static String EVENT_FORM_CATEGORY_ID = "Event Form Category ID";
    public final static String EVENT_FORM_EVENT_NAME = "Event Form Category Name";
    public final static String EVENT_FORM_TICKETS_AVAILABLE = "Event Form Tickets Available";
    public final static String EVENT_FORM_IS_ACTIVE = "Event Form Is Active";
    public static final String SMS_FILTER_CATEGORY = "SMS Filter Category";
    public static final String SMS_MSG_KEY_CATEGORY = "SMS Message Key Category";
    public static final String SMS_FILTER_EVENT = "SMS Filter Event";
    public static final String SMS_MSG_KEY_EVENT = "SMS Message Key Event";
    public static final String EVENT_MANAGEMENT_DATABASE_NAME = "Event Management Database";
    public static final String CATEGORY_LOCATION = "Category Location";
    public static final String CATEGORY_NAME = "Category Name";
}